# Dropmen Android Shopping App

Android Studio project for the Dropmen shopping demo.

## Included
- Dropmen logo supplied in the conversation
- Four supplied product images
- ₹499 displayed sale price
- “Why Now — ₹70 Only” CTA
- Minimum order quantity 10
- Supplied payment QR
- Gmail order field
- 48-hour waiting message
- Android target SDK 36

## Build
Open this folder in Android Studio (latest stable version), allow Gradle sync, then:
Build → Build APK(s)

For Google Play, use:
Build → Generate Signed Bundle / APK → Android App Bundle.

## Production warning
This project is a front-end demo. It does not verify payments, store orders remotely,
send email, or provide an admin panel. Before accepting real customer payments, connect
a compliant payment gateway and secure backend/order database. Never collect a Gmail password.

## Account flow
The app now opens a Login/Register Now screen before an order can be started.
Registration asks for name, Gmail ID, password and password confirmation.
For this demo, account state is stored locally on the device. It is NOT suitable for
real production authentication because passwords must not be stored this way.
For a real public app, connect Firebase Authentication or a secure backend and hash/
protect credentials server-side.


FINAL payment-flow fix:
- Fixed all local asset paths so logo, product images, and payment QR load correctly inside Android WebView.
- Payment flow is now: QR payment -> I Have Paid -> UTR/Transaction ID -> Gmail ID -> 48-hour waiting screen.
- Minimum quantity remains 10 and offer price remains ₹70 per item.
- Display price remains ₹499.
- UTR field accepts 8-22 alphanumeric characters.


FINAL QR FIX: Images are embedded directly in index.html so WebView cannot lose the QR/image asset paths. QR is displayed at up to 320px with a clear border.
